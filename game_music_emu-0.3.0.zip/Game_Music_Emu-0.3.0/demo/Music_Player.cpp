
// Game_Music_Emu 0.3.0. http://www.slack.net/~ant/

#include "Music_Player.h"

// comment out #include to eliminate support for that music type
#include "gme/Nsf_Emu.h"
#include "gme/Gbs_Emu.h"
#include "gme/Spc_Emu.h"
#include "gme/Vgm_Emu.h"
#include "gme/Gym_Emu.h"

// comment out to disable transparent gzip support
#include "gme/Gzip_File.h"

#include <string.h>
#include <ctype.h>
#include "SDL.h"

/* Copyright (C) 2005-2006 by Shay Green. Permission is hereby granted, free of
charge, to any person obtaining a copy of this software module and associated
documentation files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and
to permit persons to whom the Software is furnished to do so, subject to the
following conditions: The above copyright notice and this permission notice
shall be included in all copies or substantial portions of the Software. THE
SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

// Number of audio buffers per second. Adjust if you encounter audio skipping.
const int fill_rate = 50;

Music_Player::Music_Player( long sample_rate_ )
{
	sample_rate = sample_rate_;
	sound_open = false;
	emu = NULL;
}

Music_Player::~Music_Player()
{
	stop();
}

void Music_Player::stop()
{
	if ( sound_open )
	{
		sound_open = false;
		SDL_PauseAudio( true );
		SDL_CloseAudio();
	}
	delete emu;
	emu = NULL;
}

static const char* load_music_file( const char* path, long sample_rate, Music_Emu** emu_out )
{
	// extract file extension
	const int ext_len = 4;
	char ext [ext_len];
	ext [0] = 0;
	const char* p = strrchr( (char*) path, '.' );
	if ( p && strlen( p ) == ext_len )
	{
		ext [ext_len - 1] = 0;
		for ( int i = 0; i < ext_len - 1; i++ )
			ext [i] = toupper( p [i + 1] );
	}
	
	// create emulator based on extension
	Music_Emu* emu = NULL;
	if ( !*ext )
		return NULL;
	
	// support given music format if its header file has been #included
	#ifdef NSF_EMU_H
	else if ( !strcmp( ext, "NSF" ) )
		emu = new Nsf_Emu;
	#endif

	#ifdef GBS_EMU_H
	else if ( !strcmp( ext, "GBS" ) )
		emu = new Gbs_Emu;
	#endif

	#ifdef SPC_EMU_H
	else if ( !strcmp( ext, "SPC" ) )
		emu = new Spc_Emu;
	#endif

	#ifdef VGM_EMU_H
	else if ( !strcmp( ext, "VGM" ) || !strcmp( ext, "VGZ" ) )
		emu = new Vgm_Emu;
	#endif

	#ifdef GYM_EMU_H
	else if ( !strcmp( ext, "GYM" ) )
		emu = new Gym_Emu;
	#endif

	else
		return NULL;
	
	if ( !emu )
		return "Out of memory";
	
	// setup and load file
#ifdef GZIP_FILE_H
	Gzip_File_Reader in;
#else
	Std_File_Reader in;
#endif
	const char* error = emu->set_sample_rate( sample_rate );
	if ( !error )
		error = in.open( path );
	if ( !error )
		error = emu->load( in );
	if ( error )
		delete emu;
	else
		*emu_out = emu;
	return error;
}

const char* Music_Player::load( const char* path )
{
	// be sure sound thread is paused
	if ( sound_open )
	{
		SDL_PauseAudio( true );
		SDL_LockAudio();
	}
	
	// release current emulator and try to load file
	delete emu;
	emu = NULL;
	const char* error = load_music_file( path, sample_rate, &emu );

	// always unlock sound thread
	if ( sound_open )
		SDL_UnlockAudio();
	
	if ( error )
		return error;
	if ( !emu )
		return "Unsupported game music format";
	
	emu->start_track( 0 ); // have track ready in case it gets played early
	
	// open audio
	if ( !sound_open )
	{
		SDL_AudioSpec as;
		as.freq = sample_rate;
		as.format = AUDIO_S16SYS;
		as.channels = 2;
		as.silence = 0;
		as.size = 0;
		as.callback = sdl_callback;
		as.userdata = this;
		
		int buf_size = sample_rate * as.channels / fill_rate;
		as.samples = 512;
		while ( as.samples < buf_size )
			as.samples *= 2;
		
		if ( SDL_OpenAudio( &as, NULL ) < 0 )
		{
			error = SDL_GetError();
			if ( !error )
				error = "Couldn't open SDL audio";
			return error;
		}
		sound_open = true;
	}
	
	return NULL;
}

int Music_Player::tracks() const
{
	return emu ? emu->track_count() : 0;
}

void Music_Player::play( int track )
{
	if ( emu )
	{
		// sound thread must be locked out when calling emulator functions
		SDL_LockAudio();
		
		emu->start_track( track - 1 );
		
		SDL_UnlockAudio();
		
		// start audio if it hasn't been started yet
		SDL_PauseAudio( false );
	}
}

void Music_Player::pause( int b )
{
	SDL_PauseAudio( b );
}

void Music_Player::fill_buffer( sample_t* out, int count )
{
	if ( emu )
	{
		emu->play( count, out );
		
		// could do fade out here
		// ...
	}
}

void Music_Player::sdl_callback( void* self, Uint8* out, int count )
{
	((Music_Player*) self)->fill_buffer( (sample_t*) out, count / sizeof (sample_t) );
}

// game_music C wrapper

static Music_Player* player;

extern "C" const char* game_music_load( const char* path )
{
	if ( !player )
		player = new Music_Player;
	if ( !player )
		return "Out of memory";
	return player->load( path );
}

extern "C" int game_music_tracks( void )
{
	return player ? player->tracks() : 0;
}

extern "C" void game_music_play( int track )
{
	if ( player )
		player->play( track );
}

extern "C" void game_music_stop( void )
{
	delete player;
	player = NULL;
}

