
// How to play multiple game music file types

const char* filename = "test.nsf";

#include "gme/Nsf_Emu.h"
#include "gme/Gbs_Emu.h"
#include "gme/Spc_Emu.h"
#include "gme/Vgm_Emu.h"
#include "gme/Gym_Emu.h"

#include "Wave_Writer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

// Create appropriate emulator and load file
const char* load_music_file( const char* path, long sample_rate, Music_Emu** emu_out )
{
	// extract file extension
	const int ext_len = 4;
	char ext [ext_len];
	ext [0] = 0;
	const char* p = strrchr( (char*) path, '.' );
	if ( p && strlen( p ) == ext_len )
	{
		for ( int i = 0; i < ext_len; i++ )
			ext [i] = toupper( p [i + 1] );
	}
	
	// create emulator based on extension
	Music_Emu* emu = NULL;
	emu = NULL;
	if ( !strcmp( ext, "NSF" ) )
		emu = new Nsf_Emu;
	else if ( !strcmp( ext, "GBS" ) )
		emu = new Gbs_Emu;
	else if ( !strcmp( ext, "SPC" ) )
		emu = new Spc_Emu;
	else if ( !strcmp( ext, "VGM" ) )
		emu = new Vgm_Emu;
	else if ( !strcmp( ext, "GYM" ) )
		emu = new Gym_Emu;
	else
		return NULL;
	
	if ( !emu )
		return "Out of memory";
	
	// setup and load file
	const char* error = emu->set_sample_rate( sample_rate );
	if ( !error )
		error = emu->load_file( path );
	
	*emu_out = emu;
	return error;
}

void handle_error( const char* );

int main()
{
	long sample_rate = 44100;
	
	// Create appropriate emulator and load file
	Music_Emu* emu;
	handle_error( load_music_file( filename, sample_rate, &emu ) );
	if ( !emu )
		handle_error( "Unsupported game music type" );
	
	// Record several seconds of track to wave sound file
	Wave_Writer wave( sample_rate, "out.wav" );
	wave.stereo( true );
	emu->start_track( 0 );
	while ( wave.sample_count() < sample_rate * 20 )
	{
		const long buf_size = 1024;
		Music_Emu::sample_t buf [buf_size];
		emu->play( buf_size, buf );
		wave.write( buf, buf_size );
	}
	delete emu;
	
	return 0;
}

void handle_error( const char* str )
{
	if ( str )
	{
		fprintf( stderr, "Error: %s\n", str );
		exit( EXIT_FAILURE );
	}
}

