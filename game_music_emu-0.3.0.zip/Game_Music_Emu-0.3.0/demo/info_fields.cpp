
// How to read information tags from a file's header

#include "gme/Nsf_Emu.h"

#include "Wave_Writer.h"
#include <stdlib.h>
#include <stdio.h>

void handle_error( const char* );

int main()
{
	// Setup emulator and load file
	Nsf_Emu* emu = new Nsf_Emu;
	if ( !emu )
		handle_error( "Out of memory" );
	handle_error( emu->set_sample_rate( 44100 ) );
	handle_error( emu->load_file( "test.nsf" ) );
	
	// Display fields from header. Different file formats have different
	// information in their headers, and some have information elsewhere.
	// Refer to each emulator's header file and to official file
	// specification for more details.
	printf( "Game     : %-32s\n", emu->header().game );
	printf( "Author   : %-32s\n", emu->header().author );
	printf( "Copyright: %-32s\n", emu->header().copyright );
	printf( "Tracks   : %d\n",    emu->track_count() );
	
	delete emu;
	
	return 0;
}

void handle_error( const char* str )
{
	if ( str )
	{
		fprintf( stderr, "Error: %s\n", str );
		exit( EXIT_FAILURE );
	}
}

