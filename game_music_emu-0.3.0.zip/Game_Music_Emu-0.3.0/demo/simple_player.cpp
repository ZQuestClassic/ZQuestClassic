
// How to play game music files with Music_Player (requires SDL library)
//
// Run program with path to a game music file. Use the arrow keys to change
// track and spacebar to pause/resume.

#include "blargg_common.h"
#include "Music_Player.h"
#include "SDL.h"

#include <stdlib.h>
#include <stdio.h>

void handle_error( const char* );

int main( int argc, char** argv )
{
	if ( argc < 2 )
		return EXIT_FAILURE;
	
	const char* path = argv [1];
	
	// Start SDL and create minimal window to display status in
	if ( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) < 0 )
		return EXIT_FAILURE;
	atexit( SDL_Quit );
	SDL_SetVideoMode( 500, 40, 0, 0 );
	
	// Create player and open file
	Music_Player* player = new Music_Player;
	if ( !player )
		handle_error( "Out of memory" );
	handle_error( player->load( path ) );
	
	// Poll for keyboard events
	int track = 1;
	bool restart_track = true;
	bool paused = false;
	bool running = true;
	while ( running )
	{
		SDL_Delay( 1000 / 20 );
		
		SDL_Event e;
		while ( SDL_PollEvent( &e ) )
		{
			switch ( e.type )
			{
			case SDL_QUIT:
				running = false;
				break;
			
			case SDL_KEYDOWN:
				switch ( e.key.keysym.sym )
				{
				case SDLK_q:
				case SDLK_ESCAPE: // quit
					running = false;
					break;
				
				case SDLK_LEFT: // prev track
					if ( track > 1 )
						track--;
					restart_track = true;
					break;
				
				case SDLK_RIGHT: // next track
					if ( track < player->tracks() )
					{
						track++;
						restart_track = true;
					}
					break;
				
				case SDLK_SPACE: // toggle pause
					paused = !paused;
					player->pause( paused );
					break;
				}
			}
		}
		
		if ( restart_track )
		{
			restart_track = false;
			paused = false;
			player->play( track );
			
			char title [256];
			sprintf( title, "%s: %d/%d", path, track, player->tracks() );
			SDL_WM_SetCaption( title, title );
		}
	}
	
	delete player;
	
	return 0;
}

void handle_error( const char* error )
{
	if ( error )
	{
		// put error in window title
		char str [256];
		sprintf( str, "Error: %s", error );
		fprintf( stderr, str );
		SDL_WM_SetCaption( str, str );
		
		// wait for keyboard or mouse activity
		SDL_Event e;
		do
		{
			while ( !SDL_PollEvent( &e ) ) { }
		}
		while ( e.type != SDL_QUIT && e.type != SDL_KEYDOWN && e.type != SDL_MOUSEBUTTONDOWN );

		exit( EXIT_FAILURE );
	}
}

