
// Simple game music file player that uses SDL multimedia library for sound output

// Game_Music_Emu 0.3.0

#ifndef MUSIC_PLAYER_H
#define MUSIC_PLAYER_H

// C++ interface

#ifdef __cplusplus

class Music_Player {
public:
	Music_Player( long sample_rate = 44100 );
	~Music_Player();
	
	// Load game music file. NULL on success, otherwise error string.
	const char* load( const char* path );
	
	// Number of tracks in current file, or 0 if no file loaded.
	int tracks() const;
	
	// (Re)start playing track. Tracks are numbered from 1 to number of tracks.
	void play( int track );
	
	// Pause/resume playing current track.
	void pause( int );
	
	// Stop playing current file
	void stop();
	
private:
	class Music_Emu* emu;
	long sample_rate;
	int sound_open;
	
	typedef short sample_t;
	void fill_buffer( sample_t*, int );
	static void sdl_callback( void*, unsigned char*, int );
};

#endif

// C interface

#ifdef __cplusplus
	extern "C" {
#endif

// Load game music file. NULL on success, otherwise error string.
const char* game_music_load( const char* path );

// Number of tracks in currently loaded file
int game_music_tracks( void );

// (Re)start track in current file, numbered from 1 to number of tracks
void game_music_play( int track );

// Stop playing track and free memory
void game_music_stop( void );

#ifdef __cplusplus
	}
#endif

#endif

