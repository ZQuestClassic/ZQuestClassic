
// How to load a game music file and record it to a wave sound file

#include "gme/Nsf_Emu.h"

#include "Wave_Writer.h"
#include <stdlib.h>
#include <stdio.h>

void handle_error( const char* );

int main()
{
	long sample_rate = 44100;
	
	// Setup emulator and load file
	Nsf_Emu* emu = new Nsf_Emu;
	if ( !emu )
		handle_error( "Out of memory" );
	handle_error( emu->set_sample_rate( sample_rate ) );
	handle_error( emu->load_file( "test.nsf" ) );
	
	// Record several seconds of first track to wave sound file
	Wave_Writer wave( sample_rate, "out.wav" );
	wave.stereo( true );
	emu->start_track( 0 );
	while ( wave.sample_count() < sample_rate * 20 )
	{
		const long buf_size = 1024;
		Music_Emu::sample_t buf [buf_size];
		
		// fill buffer
		emu->play( buf_size, buf );
		
		// write to sound file
		wave.write( buf, buf_size );
	}
	
	// Done using emulator
	delete emu;
	
	return 0;
}

void handle_error( const char* str )
{
	if ( str )
	{
		fprintf( stderr, "Error: %s\n", str );
		exit( EXIT_FAILURE );
	}
}

