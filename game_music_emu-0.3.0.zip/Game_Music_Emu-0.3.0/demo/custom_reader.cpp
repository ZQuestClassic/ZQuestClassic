
// How to use custom data reader to load from gzip file or memory block

#include "gme/Gzip_File.h"

#include "gme/Nsf_Emu.h"
#include "Wave_Writer.h"

#include <stdlib.h>
#include <stdio.h>

void handle_error( const char* );

int main()
{
	long sample_rate = 44100;
	
	// Setup emulator
	Nsf_Emu* emu = new Nsf_Emu;
	if ( !emu )
		handle_error( "Out of memory" );
	handle_error( emu->set_sample_rate( sample_rate ) );
	
	// Load from gzipped file (will also work if file isn't gzipped)
	Gzip_File_Reader in;
	handle_error( in.open( "test.nsf.gz" ) );
	handle_error( emu->load( in ) );
	
	// Could also use music data already loaded into memory
	//char* data = ...
	//long size = ...
	//Mem_File_Reader in( data, size );
	//handle_error( emu->load( in ) );

	// Record several seconds of track to wave sound file
	Wave_Writer wave( sample_rate, "out.wav" );
	wave.stereo( true );
	emu->start_track( 0 );
	while ( wave.sample_count() < sample_rate * 20 )
	{
		const long buf_size = 1024;
		Music_Emu::sample_t buf [buf_size];
		emu->play( buf_size, buf );
		wave.write( buf, buf_size );
	}
	delete emu;
	
	return 0;
}

void handle_error( const char* str )
{
	if ( str )
	{
		fprintf( stderr, "Error: %s\n", str );
		exit( EXIT_FAILURE );
	}
}

