
// How to use Effects_Buffer to stereo effects to music

#include "gme/Effects_Buffer.h"

#include "gme/Nsf_Emu.h"
#include "Wave_Writer.h"
#include <stdlib.h>
#include <stdio.h>

void handle_error( const char* );

int main()
{
	long sample_rate = 44100;
	
	// Setup emulator with custom buffer and load file
	Music_Emu* emu = new Nsf_Emu;
	if ( !emu )
		handle_error( "Out of memory" );
	Effects_Buffer buf;
	emu->set_buffer( &buf );
	handle_error( emu->set_sample_rate( sample_rate ) );
	handle_error( emu->load_file( "test.nsf" ) );
	
	// Configure effects buffer
	Effects_Buffer::config_t cfg;
	cfg.pan_1 = -0.12;          // put first two channels slightly off-center
	cfg.pan_2 = 0.12;
	cfg.reverb_delay = 88;      // delays are in milliseconds
	cfg.reverb_level = 0.20;    // significant reverb
	cfg.echo_delay = 61;        // echo applies to noise and percussion channels
	cfg.echo_level = 0.15;
	cfg.delay_variance = 18;    // left/right delays must differ for stereo effect
	cfg.effects_enabled = true;
	buf.config( cfg );
	
	// Record several seconds of track to wave sound file
	Wave_Writer wave( sample_rate, "out.wav" );
	wave.stereo( true );
	emu->start_track( 0 );
	while ( wave.sample_count() < sample_rate * 20 )
	{
		const long buf_size = 1024;
		Music_Emu::sample_t buf [buf_size];
		emu->play( buf_size, buf );
		wave.write( buf, buf_size );
	}
	delete emu;
	
	return 0;
}

void handle_error( const char* str )
{
	if ( str )
	{
		fprintf( stderr, "Error: %s\n", str );
		exit( EXIT_FAILURE );
	}
}

