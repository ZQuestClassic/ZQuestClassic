/* Allegro datafile object indexes, produced by grabber v4.2.0 (beta4), MacOS X */
/* Datafile: /Users/thomasharte/Allegro Demo Game/build/Development/demo.dat */
/* Date: Fri Jul  8 12:41:18 2005 */
/* Do not hand edit! */

#define DEMO_BMP_BACK                    0	/* BMP  */
#define DEMO_FONT                        1	/* FONT */
#define DEMO_FONT_LOGO                   2	/* FONT */
#define DEMO_GAME_PALETTE                3	/* PAL  */
#define DEMO_MENU_PALETTE                4	/* PAL  */
#define DEMO_MIDI_INGAME                 5	/* MIDI */
#define DEMO_MIDI_INTRO                  6	/* MIDI */
#define DEMO_MIDI_MENU                   7	/* MIDI */
#define DEMO_MIDI_SUCCESS                8	/* MIDI */
#define DEMO_SAMPLE_BUTTON               9	/* SAMP */
#define DEMO_SAMPLE_WELCOME              10	/* SAMP */
