#ifndef		__DEMO_KEYBOARD_H__
#define		__DEMO_KEYBOARD_H__

#include <allegro.h>
#include "virtctl.h"

VCONTROLLER *create_keyboard_controller(const char *config_path);

#endif				/* __DEMO_KEYBOARD_H__ */
