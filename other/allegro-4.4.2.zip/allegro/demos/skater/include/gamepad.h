#ifndef		__DEMO_GAMEPAD_H__
#define		__DEMO_GAMEPAD_H__

#include <allegro.h>
#include "virtctl.h"

VCONTROLLER *create_gamepad_controller(const char *config_path);

#endif				/* __DEMO_GAMEPAD_H__ */
