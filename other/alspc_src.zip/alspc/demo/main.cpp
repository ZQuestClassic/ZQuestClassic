#include <assert.h>
#include "main.h"
#include <stdio.h>
#include <alspc.h>

#include <string>

const int buffer_multiplier = 20;

volatile int Main::counter = 0;

void timer_handler()
{
    Main::counter += 10;
}

END_OF_FUNCTION(timer_handler);

Main::Main() : songs()
{
    soundOn = true;
    fpsOn = false;
    buffer = NULL;
    windowed = false;
    
    last_fps = 0;
    update_counter = 0;
    frame_count = 0;
    frame_counter = 0;
    
    alspc_player = NULL;

    sampling_rate = 44100;
    stereo = 1;
    is_interpolation = 1;
	
    quit = true;
    datafile = NULL;
    
}

// adds all filenames that match pattern to the vector
void glob(const char *pattern, std::vector<std::string> &result)
{
    char buf[1024];
    
    al_ffblk info;
    
    int temp = al_findfirst (pattern, &info, FA_RDONLY | FA_ARCH);
    
    while (temp == 0)
    {
        replace_filename(buf, pattern, info.name, sizeof(buf));
        result.push_back (std::string(buf));
        temp = al_findnext(&info);
    }
            
    al_findclose(&info);
}

int Main::init(int argc, const char *const *argv)
// returns 1 on success, 0 on failure
{
    LOCK_VARIABLE(Main::counter);
    LOCK_FUNCTION(timer_handler);
    if (allegro_init () < 0)
    {
        allegro_message ("init failed");
        return 0;
    }
    
    alspc_install();
    
    std::vector <std::string> filenames;
    
    // parse command line arguments
    int i;
    for (i = 1; i < argc; i++)
    {
	int temp;
        if (sscanf (argv[i], "-sampling-rate=%i", &temp) == 1)
	{
		sampling_rate = temp;
	}
	else if (strcmp (argv[i], "-mono") == 0)
	{
		stereo = 0;
	}
	else if (strcmp (argv[i], "-stereo") == 0)
	{
		stereo = 1;
	}
	else if (strcmp (argv[i], "-no-interpolation") == 0)
	{
		is_interpolation = 0;
	}
	else if (strcmp (argv[i], "-windowed") == 0)
        {
            windowed = true;
        }
        else if (strcmp (argv[i], "-showfps") == 0)
        {
		fpsOn = true;
        }
        else
        {
            glob (argv[i], filenames);
        }            
    }   
    
    if (filenames.size() <= 0)
    {
	    allegro_message ("\
Plays SNES .SPC files\n\
Usage:\n\
\n\
play filepattern [filepattern ...] [options]\n\
\n\
filepatterns may contain several spc files or one allegro datafile\n\
possible options are:\n\
    -sampling-rate=nnnn -> sets sampling rate, for example\n\
	      a sampling rate of 44100 is high quality.\n\
    -mono\n\
    -stereo\n\
    -no-interpolation -> reduced sound quality\n\
    -windowed -> run in windowed mode\n\
    -showfps -> show a frames per second counter\n");
	    return 0;
    }    
    if (install_keyboard () < 0)
    {
        allegro_message ("install keyboard failed");
        return 0;
    }
    if (install_timer() < 0)
    {
        allegro_message ("install timer failed");
        return 0;
    }    
    set_volume_per_voice (1);
    if (soundOn && install_sound(DIGI_AUTODETECT, MIDI_NONE, NULL) < 0)
    {
        // could not get sound to work
        soundOn = false;
        allegro_message ("Could not initialize sound. Sound is turned off.\n%s\n", allegro_error);
    }   
    if (install_int (timer_handler, 10) < 0)
    {
        allegro_message ("installation of timer handler failed");
        return 0;
    }
    set_color_depth (16);
    if (windowed)
    {
        if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,320,240,0,0)!=0)
        {
            allegro_message("Unable initialize graphics module\n%s\n", allegro_error);
            return 0;
        }
    }
    else
    {
        if (set_gfx_mode(GFX_AUTODETECT,320,240,0,0)!=0)
        {
            allegro_message("Unable initialize graphics module\n%s\n", allegro_error);
            return 0;
        }
    }
    buffer = create_bitmap(SCREEN_W, SCREEN_H);
    if (!buffer)
    {
        allegro_message ("Error creating background buffer");
        return 0;
    }
    set_window_title ("Allegro SPC player - Martijn van Iersel");
    text_mode (-1);
    
    // spc init code:
    std::vector<std::string>::iterator j;
    for (j = filenames.begin(); j != filenames.end(); ++j)
    {      
        
        ALSPC_DATA *temp;
        if (!datafile && strcmp (get_extension (j->c_str()), "dat") == 0)
        {
            datafile = load_datafile (j->c_str());
            if (datafile) 
            {
                DATAFILE *pos = datafile;
                while (pos->type != DAT_END)
                {
                    if (pos->type == DAT_ALSPC)
                    {
                        songs.push_back ((ALSPC_DATA*)pos->dat);
                    }
                    pos++;
                }
            }
        }
        else
        {
            if (!(temp = alspc_load (j->c_str())))
            {
                allegro_message ("Couldn't load SPC file %s", j->c_str());            
            }
            else
            {
                songs.push_back (temp);
                owned_songs.push_back (temp);
            }
        }
    }
    
    if (songs.size() <= 0)
    {
        return 0; // must have already had an error message...
    }
    
    current = songs.begin();
    if (!(alspc_player = alspc_start (*current, sampling_rate, 255, 128, stereo, is_interpolation)))
    {
        allegro_message ("Couldn't create a valid ALSPC_PLAYER");
        return 0;
    }
        
    return 1;
}

void Main::run()
{
    quit = false;
    while (!quit) 
    {
        while ((counter - update_counter) > 40) // update 25 times/sec
        {
            
            update_counter += 40;
            int update_start = counter;
            update ();
                        
            // check to see if update takes too long
            if (counter - update_start > 40)
            {
                // we probably can't catch up anymore.
                // move update_counter ahead, or we have to
                // catch up even more next loop
                update_counter = counter;
                break;
            }
        }
    
        alspc_poll (alspc_player);
        
        draw();
        if (fpsOn)
        {
            text_mode (-1);            
            textprintf (buffer, font, 0, 0, makecol(255, 255, 255), "fps: %d", last_fps);
        }
        blit (buffer, screen, 0, 0, 0, 0, buffer->w, buffer->h);
        
        if ((counter - frame_counter) > 1000)
        {
            last_fps = frame_count;
            frame_count = 0;
            frame_counter = counter;
        }
        frame_count++;        
    }            
}

void Main::update()
{
    if (key[KEY_ESC]) quit = true; // emergency bail out               
        
    if (keypressed())
    {
        readkey();
        current++;
        if (current == songs.end()) current = songs.begin();
        
        alspc_stop (alspc_player);
        alspc_player = alspc_start (*current, sampling_rate, 255, 128, stereo, is_interpolation);
        
    }
        
    // every 1/100 sec, we advance sample_rate / 100 samples
    //(char*)(last_buf) += (spc_config.sampling_rate * bytes_per_sample / 100); 
}

void Main::draw()
{
    
    clear_bitmap (buffer);
	
    // print some info
    textprintf (buffer, font, 0,  8, makecol (0, 255, 255), "songname  : %s", (*current)->id.songname);
    textprintf (buffer, font, 0, 16, makecol (255, 255, 0), "gametitle : %s",(*current)->id.gametitle);
    textprintf (buffer, font, 0, 24, makecol (255, 255, 255), "sampling rate = %i", sampling_rate);
    textprintf (buffer, font, 0, 32, makecol (255, 255, 255), "stereo = %i", stereo);
    textprintf (buffer, font, 0, 40, makecol (255, 255, 255), "interpolation = %i", is_interpolation);
    textprintf (buffer, font, 0, 48, makecol (255, 255, 255), "samples per update = %i", alspc_player->sample_count * ALSPC_BUFFER_MULTIPLIER);
    
    if (!alspc_player) return;
        
    unsigned short *data = (unsigned short *)(alspc_player->stream->samp->data);
    unsigned long len = alspc_player->stream->samp->len;
    unsigned int pos = voice_get_position (alspc_player->stream->voice);    
    
    int skipfactor = 2;
    int displaylen = (pos + (SCREEN_W * skipfactor) > len ? (len - pos) / skipfactor : SCREEN_W);
        
    int i;
    for (i = 0; i < displaylen; i++)
    {              
        if (alspc_player->stream->samp->stereo)
        {
            int yco = (int)(data[pos + i * 2 * skipfactor]) * (int)(SCREEN_H) / (int)(65536);
            putpixel (buffer, i, yco, makecol (0, 0, 255));        
            yco = (int)(data[pos + i * 2 * skipfactor + 1]) * SCREEN_H / 65536;
            putpixel (buffer, i, yco, makecol (0, 255, 0));        
        }
        else
        {
            int yco = (int)(data[pos + i * skipfactor]) * SCREEN_H / 65536;
            putpixel (buffer, i, yco, makecol (0, 0, 255));        
        }
    }
    
    /*    
    if (!last_buf) return;
        
    unsigned short * samples = (unsigned short *) last_buf;    
    
    int i;
    for (i = 0; i < SCREEN_W; ++i)
    {
        int yco = (int)(samples[i * 2]) * SCREEN_H / 65536;
        putpixel (buffer, i, yco, makecol (0, 0, 255));        
    }
    */
    //struct timespec t = {0, 1};
    //nanosleep (&t, 0);
    
}

Main::~Main()
{
    if (buffer) destroy_bitmap (buffer);    
        
    // spc close code
    std::vector<ALSPC_DATA*>::iterator i;
    for (i = owned_songs.begin(); i != owned_songs.end(); ++i)
    {
        alspc_unload (*i);
        *i = NULL;
    }
    alspc_stop (alspc_player);        
    alspc_uninstall();
    if (datafile) unload_datafile (datafile);
}

int main(int argc, const char *const *argv)
{
    Main m;
    if (m.init(argc, argv))
    {        
        m.run();
    }
    return 0;
} END_OF_MAIN();
