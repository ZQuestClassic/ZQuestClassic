#ifndef MAIN_H
#define MAIN_H

#include <allegro.h>
#include <alspc.h>
#include <vector>

class Main
{
private:
    BITMAP *buffer;
    
    int frame_count;
    int frame_counter;
    int last_fps;
    int update_counter;

    int sampling_rate;
    bool stereo;
    bool is_interpolation;

    // game options
    bool soundOn;
    bool fpsOn;
    bool windowed;
    bool quit;
       
    void draw ();
    void update ();
   
    std::vector <ALSPC_DATA*> songs;
    std::vector <ALSPC_DATA*> owned_songs; // owned copies, must delete
    std::vector <ALSPC_DATA*>::iterator current;    
    
    ALSPC_PLAYER *alspc_player;
    
    DATAFILE *datafile;    
    
public:
    static volatile int counter;
    int getCounter () { return counter; }
    Main ();
    int init(int argc, const char *const *argv);
    void run();
    void done();
    ~Main();
    
    bool isSoundOn() { return soundOn; }
};

#endif
