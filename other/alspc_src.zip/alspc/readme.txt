alspc, by Martijn van Iersel (amarillion@yahoo.com)
version 0.91

Introduction
============

alspc is an add-on for allegro that lets you play SPC music in your own 
programs. SPC is music from the SNES and can be created by dumping with 
certain SNES emulators.

In short, alspc let's you play your favourite snes music in your own 
allegro games.

alspc is written by Martijn van Iersel (amarillion@yahoo.com).
You can find the latest version at my website: 
http://www.student.wau.nl/~martijni

alspc is based on xmms-spc by AGAWA Koji <kaoru-k@self-core.org>,
and it uses the snes9x core by Gary Henderson <gary@daniver.demon.co.uk> 
and Jerremy Koot <jkoot@snes9x.com>

alspc is written in C++. However, you can use it in C programs as well.

Basic Installation
==================

The installation procedure is generally the same as for allegro itself. 

step 1. unzip the package you downloaded. After unzipping, a directory 
  named alspc will be created. This will be referred to as the base 
  directory from now on.

step 2. run fix.bat or fix.sh from the base directory with a parameter 
  specifying the platform.
  supported platforms are linux, mingw32 and djgpp. For example:

 linux: 
    ./fix.sh linux
    
 dos (djgpp):
    fix djgpp

 windows (mingw / dev-cpp):
    fix mingw32
    
step 3. make

step 4. make install (you may need root access for this step in linux)
  this last step will copy the library libalspc.a and the include file alspc.h to the 
  proper directories.
  
Quick start tutorial
====================

If you have some SPC music you can easily play it in your program. 
This is how:

1. add the following line at the top of your program

  #include "alspc.h"

2. call alspc_install() to initialize the library. This should be done
after allegro_init()

  alspc_install();

3. to load for example mario.spc from disk, use the following code:

  ALSPC_DATA *alspc_data;
  alspc_data = alspc_load ("mario.spc");
  if (!alspc_data) { allegro_message ("Couldn't load mario.spc!"); }

this code will allocate the memory for the ALSPC_DATA structure itself,
so you don't have to worry about that.

4. use this code to start playing the previously loaded alspc_data:

  ALSPC_PLAYER *alspc_player;
  alspc_player = alspc_start (alspc_data, 44100, 255, 128, 1, 1);

note: see the reference section for more information on the 
parameters passed to alspc_start.

5. now you need to call alspc_poll as often as possible but at least 
five times per second. Don't call it from a timer interrupt as the polling
process is computationally very intensive.

  alspc_poll (alspc_player);
  
6. when done playing music, you can clean up in three steps:

  alspc_stop (alspc_player);
  alspc_unload (alspc_data);
  alspc_uninstall ();
  
note that these functions will free the ALSPC_DATA and ALSPC_PLAYER 
functions so you don't have to.

7. Don't forget to link with -lalspc. 

note: alspc is written in C++. You can use it in C-only projects,
but you still need to link with -lstc++ because alspc depends on it.

so, for a C project you link with

  gcc your_object.o -lalleg -lalspc -lstdc++

for a C++ project you can simply use:

  g++ your_object.o -lalleg -alspc


Datafiles
=========

You can store SPC files in datafiles and make use of allegro's
packfile compression and password protection in this way. The process
is very simple. 

1. First you have to use the grabber to create a new object (type "other")
and manually change the type to "ASPC". Then you can simply grab 
your SPC file.

2. The ASPC datafile object is recognized by load_datafile, but only
after you have called alspc_install(). It is critical that you call 
aspc_install() after allegro_init() but before you load your datafiles.

3. The .dat field of the DATAFILE object corresponds to an ALSPC_DATA
object. The .type field of the object should 
be DAT_ALSPC. For example, if the ASPC object is named MARIO then it 
can be played in the following way:

  ALSPC_PLAYER *alspc_player;
  alspc_player = 
    alspc_start ((ALSPC_DATA*)(datafile[MARIO].dat), 44100, 255, 128, 1, 1);

  // call repeatedly:
  alspc_poll (alspc_player);

  // call when done:
  alspc_stop (alspc_player);
  
note: don't call alspc_unload to unload SPC data from datafiles. Use
unload_datafile() instead, as you are used to.

Demo
====

This package comes with a demo that is compiled automatically 
together with the library. The demo is named play / play.exe / playw.exe
and can be found in the base directory of alspc.

usage:
    play filepattern [filepattern ...] [options]

filepattern may be any filename or wildcard pattern for .spc or allegro
.dat files. If you specify a .dat file, all ASPC objects in that datafile
will be loaded.

Options can be:
    -sampling-rate=nnnn -> sets sampling rate, for example
	      a sampling rate of 44100 is high quality.
    -mono
    -stereo
    -no-interpolation -> reduced sound quality
    -windowed -> run in windowed mode
    -showfps -> show a frames per second counter

When the program is running you can quit with ESC or 
select the next specified song with any other key.

API Reference
=============

The ALSPC_DATA struct has an id field that stores
identification information about the song, such as the
name of the song and the game it originates from. You can
access this information directly in your program.
The id field is an SPC_ID666 struct which is
defined below:

typedef struct ALSPC_DATA
{
    ...
    SPC_ID666 id;
} ALSPC_DATA;

typedef struct SPC_ID666
{
  char songname[33];
  char gametitle[33];
  char dumper[17];
  char comments[33];
  char author[33];
  int playtime;
  int fadetime;
  SPC_EmulatorType emulator;
} SPC_ID666;

void alspc_install ();

  Use this function to initialize the alspc module. Call
  this after allegro_init(), but before you use any other
  of the alspc functions and also before you load any datafiles
  containing SPC objects.

void alspc_uninstall ();

  call this at the end of your program to clean up
  the alspc engine properly

ALSPC_DATA *alspc_load (const char *fname);
void alspc_unload (ALSPC_DATA *alspc);

  This function can be used to load SPC files from disk.
  When the file is loaded successfully, the function
  creates an ALSPC_DATA object and returns a pointer to it.
  It returns NULL when an error has occured.
  Use alspc_unload to clean up ALSPC_DATA objects.

ALSPC_PLAYER *alspc_start 
    (ALSPC_DATA *alspc, 
    int sampling_rate, 
    int volume, 
    int pan, 
    int stereo, 
    int is_interpolation);

  Call this function to start playing music. You can only
  play one spc file at a time, and you'll get a NULL pointer when 
  calling alspc_start when another song is already playing.
  
  sampling_rate is the sampling rate, a good value is 44100 for
  CD-quality playback (Corresponding to 44.1 kHz of course).  
  volume can range from 0 to 255, 255 being the maximum volume
  pan can range from 0 to 255, 128 being normal panning (equal left and right)
  stereo can be 1 or 0
  is_interpolation can be 1 or 0
  
  To reduce processing cost on slower computers,
  use a lower sampling rate (e.g. 22050), and/or turn stereo 
  and interpolation off.
  
void alspc_stop (ALSPC_PLAYER *player);

  Call this to stop music and clean up an ALSPC_PLAYER object
  created with alspc_start

void alspc_poll (ALSPC_PLAYER *alspc);

  This function should be called regularily to fill the
  audiostream buffer with sample data. As a rule of thumb, you should
  call this function at least five times per second but preferably
  much more often. Don't call this function from inside a timer interrupt.

License
=======

(c) 2003 Martijn van Iersel (amarillion@yahoo.com)
This library is free software, you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (see the file "copying.txt"); if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.